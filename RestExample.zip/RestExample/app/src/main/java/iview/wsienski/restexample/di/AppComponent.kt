package iview.wsienski.restexample.di

import dagger.Component
import iview.wsienski.restexample.RestExampleApp
import javax.inject.Singleton

/**
 * Created by Witold Sienski on 20.11.2018.
 */
@Singleton
@Component(modules = arrayOf(NetModule::class))
interface AppComponent {

    fun inject(restExampleApp: RestExampleApp)

}
