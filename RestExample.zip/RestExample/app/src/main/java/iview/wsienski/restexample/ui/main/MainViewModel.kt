package iview.wsienski.restexample.ui.main

import android.arch.lifecycle.LiveData
import android.arch.lifecycle.LiveDataReactiveStreams
import android.arch.lifecycle.ViewModel
import iview.wsienski.restexample.data.APIService
import iview.wsienski.restexample.data.model.User
import javax.inject.Inject

class MainViewModel
@Inject constructor(val apiService: APIService) : ViewModel(), IMainViewModel {

    override fun loadUsers(since: Int): LiveData<List<User>> =
        LiveDataReactiveStreams.fromPublisher<List<User>> { apiService.listUsers(since) }

}
