package iview.wsienski.restexample.ui.main

import android.arch.lifecycle.LiveData
import iview.wsienski.restexample.data.model.User

/**
 * Created by Witold Sienski on 20.11.2018.
 */
interface IMainViewModel {
    fun loadUsers(since: Int): LiveData<List<User>>
}